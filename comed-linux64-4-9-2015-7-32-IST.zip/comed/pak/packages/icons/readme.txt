All files are PNG files with a .jpg ending so that Sauerbraten finds them.

action.jpg
arrow_bw.jpg
arrow_fw.jpg
checkbox_off.jpg
checkbox_on.jpg
exit.jpg
info.jpg
menu.jpg
radio_off.jpg
radio_on.jpg

server.jpg
serverfull.jpg
serverlock.jpg
serverpriv.jpg
serverunk.jpg

snoutx10k.jpg
snoutx10k_blue.jpg
snoutx10k_red.jpg

spectator.jpg (based on a CC BY-NC version by P.J. Onori, http://www.somerandomdude.com/)

(c) 2013 Alexander "pix" Willing
